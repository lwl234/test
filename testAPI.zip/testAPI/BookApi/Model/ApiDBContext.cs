﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookApi.Model
{
    public class ApiDBContext : DbContext
    {
        public ApiDBContext(DbContextOptions<ApiDBContext> options): base(options)
        {
        }

        public DbSet<Book> Book { get; set; }
        //public DbSet<Book> Books { get; set; }
    }
}
