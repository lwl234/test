﻿MS SQL server Book database and Book table

USE [Book]
GO

/****** Object:  Table [dbo].[Book]    Script Date: 5/9/2021 5:49:46 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Book](
	[Book_ID] [int] IDENTITY(1000001,1) NOT NULL,
	[Display_ID] [varchar](50) NULL,
	[Creator] [varchar](50) NULL,
	[Creation_Time] [datetime] NULL,
	[Edit_Time] [datetime] NULL,
	[Status] [nvarchar](50) NULL DEFAULT ('Active'),
	[BookName] [nvarchar](255) NULL,
	[Category] [nvarchar](100) NULL,
	[Price ] [float] NULL,
	[Author] [nvarchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[Book_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO
